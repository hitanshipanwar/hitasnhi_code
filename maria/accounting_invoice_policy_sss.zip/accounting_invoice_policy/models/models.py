# -*- coding: utf-8 -*-
from odoo import models, fields
from itertools import groupby

class ResPartner(models.Model):
    _inherit = 'res.partner'
    accounting_invoice_policy = fields.Selection([('combine_invoices', 'Combine Invoices'),('never_combine_invoice', 'Never Combine Invoices'), 
                     ('split_invoice_per_vat', 'Split Invoice per VAT')], required=True, default='combine_invoices', string="Accounting Invoice Policy")

class SaleOrderLine(models.Model):
    _inherit = 'sale.order'

    def _create_invoices(self, grouped=False, final=False, date=None):
        # print('ssssssssssssssssss3434sssssssssssssssssssssssssssss', grouped)
        if self._context.get('by_vat'):
            # print("Yes I Got Context >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
            if not self.env['account.move'].check_access_rights('create', False):
                try:
                    self.check_access_rights('write')
                    self.check_access_rule('write')
                except AccessError:
                    return self.env['account.move']

            # 1) Create invoices.
            invoice_vals_list = []
            invoice_item_sequence = 0 # Incremental sequencing to keep the lines order on the invoice.
            for order in self:
                order = order.with_company(order.company_id)
                # print('==================================order',order)
                current_section_vals = None
                down_payments = order.env['sale.order.line']
                # print('==================================down_payments', down_payments)

                invoice_vals = order._prepare_invoice()
                # print('======================invoice_vals',invoice_vals)
                invoiceable_lines = order._get_invoiceable_lines(final)
                # print('=================================invoiceable_lines==',invoiceable_lines)

                if not any(not line.display_type for line in invoiceable_lines):
                    continue

                invoice_line_vals = []
                grouped_vals = []
                down_payment_section_added = False
                for line in invoiceable_lines:
                    if not down_payment_section_added and line.is_downpayment:
                        # Create a dedicated section for the down payments
                        # (put at the end of the invoiceable_lines)
                        invoice_line_vals.append(
                            (0, 0, order._prepare_down_payment_section_line(
                                sequence=invoice_item_sequence,
                            )),
                        )
                        down_payment_section_added = True
                        invoice_item_sequence += 1
                        
                    grouped_vals.append(line._prepare_invoice_line(
                            sequence=invoice_item_sequence,
                        ))

                
                    invoice_line_vals.append(
                        (0, 0, line._prepare_invoice_line(
                            sequence=invoice_item_sequence,
                        )),
                    )
                    invoice_item_sequence += 1

                invoice_vals['invoice_line_ids'] += invoice_line_vals
                # invoice_vals['invoice_line_ids'] += grouped_vals
                invoice_vals_list.append(invoice_vals)
                # print('invoice_vals_list--------------------------------------',invoice_vals_list)
                # print('---------------------------------------invoice_vals_list--',invoice_vals_list)

            # if not invoice_vals_list:
            #     raise self._nothing_to_invoice_error()

            # 2) Manage 'grouped' parameter: group by (partner_id, currency_id).
            # print("Grouping >>>>>>>>>>>>>>>>>>>>>>>>>>>>. ",not grouped)
            if not grouped:
                new_invoice_vals_list = []
                invoice_grouping_keys = self._get_invoice_grouping_keys()
                invoice_vals_list = sorted(
                    invoice_vals_list,
                    key=lambda x: [
                        x.get(grouping_key) for grouping_key in invoice_grouping_keys
                    ]
                )
                for grouping_keys, invoices in groupby(invoice_vals_list, key=lambda x: [x.get(grouping_key) for grouping_key in invoice_grouping_keys]):
                    origins = set()
                    payment_refs = set()
                    refs = set()
                    ref_invoice_vals = None
                    # print('ref_invoice_vals=========================',ref_invoice_vals)
                    for invoice_vals in invoices:
                        # print('ref_invoice_vals=========================',invoice_vals)
                        if not ref_invoice_vals:
                            # print('ifffffffffffffffffffffffffffffffffffff')
                            ref_invoice_vals = invoice_vals
                            # print('ref_invoice_vals========================',ref_invoice_vals)
                        else:
                            # print('elseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
                            ref_invoice_vals['invoice_line_ids'] += invoice_vals['invoice_line_ids']
                            # print('-------------------------------ref_invoice_vals',ref_invoice_vals)
                        origins.add(invoice_vals['invoice_origin'])
                        payment_refs.add(invoice_vals['payment_reference'])
                        refs.add(invoice_vals['ref'])
                    ref_invoice_vals.update({
                        'ref': ', '.join(refs)[:2000],
                        'invoice_origin': ', '.join(origins),
                        'payment_reference': len(payment_refs) == 1 and payment_refs.pop() or False,
                    })
                    # print('ref_invoice_vals--------------------------',ref_invoice_vals)
                    new_invoice_vals_list.append(ref_invoice_vals)
                    # print('=======new_invoice_vals_list==============', new_invoice_vals_list)
                invoice_vals_list = new_invoice_vals_list
                # print('\n\n\n--New List -------------------------------------------',invoice_vals_list)

            # print("Simple withthout groupo >??????????????????// ", grouped_vals, end='\n\n\n')
            # print("Original List  >>>>>>>>>>>>>>.. ", invoice_vals_list, end='\n\n\n')
            # sss
            if len(invoice_vals_list) < len(self):
                SaleOrderLine = self.env['sale.order.line']
                for invoice in invoice_vals_list:
                    sequence = 1
                    for line in invoice['invoice_line_ids']:
                        line[2]['sequence'] = SaleOrderLine._get_invoice_line_sequence(new=sequence, old=line[2]['sequence'])
                        sequence += 1

            # Manage the creation of invoices in sudo because a salesperson must be able to generate an invoice from a
            # sale order without "billing" access rights. However, he should not be able to create an invoice from scratch.
            print("\n\nFinal >>>>>>>>>>>>>>>>>>>>>>>>.. ", invoice_vals_list)
            taxes = []
            for order in invoice_vals_list[0]['invoice_line_ids']:
                for tax in order[2]['tax_ids'][0][2]:
                    if tax not in taxes:
                        taxes.append(tax)

                # print('----------loop od order liness--------------------------------------------',order)
            # print('tax=====================================',taxes)
            orderline = {}
            for tax in taxes:
                for orders in invoice_vals_list:
                    print('-------------------------------orderrrrrrrrrrrr---',orders)
                    print('getttttttttttttttttttttttttttttttttttt',orders.get('invoice_line_ids'))
                    for order in orders.get('invoice_line_ids'):
                        
                        print('--hitnashiiii--------------------------------------',order[2]['tax_ids'][0][2][0])
                        if order[2]['tax_ids'][0][2][0] == tax:
                            orderline.setdefault(tax, []).append(order)
                        


            #     for order in invoice_vals_list[0]['invoice_line_ids']:
            #     # print('==============================',tax)
            #         print('--hitnashiiii--------------------------------------',order[2]['tax_ids'][0][2][0])
            #         if order[2]['tax_ids'][0][2][0] == tax:
            #             orderline.setdefault(tax, []).append(order)

            #             # orderline[tax] = [order]
            #             print('ifffffffffffffffffffffffffffffffffffffff')
            #             # orderline.append(order)
            print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',orderline)

            # for invoice in orderline:
            #     print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>values',orderline[invoice])
            #     account_move = self.env['account.move.line']
            #     move_id = account_move.create(orderline[invoice])
            #     invoice_vals_list = orderline[invoice]
            #     moves = self.env['account.move'].sudo().with_context(default_move_type='out_invoice').create(invoice_vals_list)
            #     print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~move ',move_id)
            #     # orderline[invoice]._create_invoices()/

            #     # for rec in orderline[invoice]:
            #     #     print('recccccccccccccccccccccccccccccc',rec)
            #     #     rec._create_invoices()
            #     # print('invoiceeeeeeeeeeeeeeeeeeeeeeeeeee',invoice,'>>>>>>>>>>c' ,orderline[invoice])

            sss

                    # print('taxes----------------------------------',taxes)
                # print('--------loop od order liness-----------------------------------',invoice_vals_list[0]['invoice_line_ids'])


            # ssss
            moves = self.env['account.move'].sudo().with_context(default_move_type='out_invoice').create(invoice_vals_list)

            # 4) Some moves might actually be refunds: convert them if the total amount is negative
            # We do this after the moves have been created since we need taxes, etc. to know if the total
            # is actually negative or not
            if final:
                moves.sudo().filtered(lambda m: m.amount_total < 0).action_switch_invoice_into_refund_credit_note()
            for move in moves:
                move.message_post_with_view('mail.message_origin_link',
                    values={'self': move, 'origin': move.line_ids.mapped('sale_line_ids.order_id')},
                    subtype_id=self.env.ref('mail.mt_note').id
                )
            # sss
            return moves
        else:
            # print("No Context not passed >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.")
            return super()._create_invoices(grouped=False, final=False, date=None)

    def _get_invoice_grouping_keys(self):
        print("Contect.................... ", self._context)
        if self._context.get('by_vat'):
            print("Contecxt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",self._context)
            return ['company_id', 'tax_id','tax_ids', 'currency_id', 'partner_id']
        else:
            print("No Co tect >>>>>>>>>>>>>>>>>>>",self._context)
            return ['company_id', 'partner_id', 'currency_id']

    
class SaleAdvancePaymentInv(models.TransientModel):
    _inherit = 'sale.advance.payment.inv'


    def create_invoices(self):
        print('create_invoices----------------------------mmm--')
        sale_orders = self.env['sale.order'].browse(self._context.get('active_ids', []))
        for rec in sale_orders:
            if rec.partner_id.accounting_invoice_policy == 'combine_invoices':
                # sale_orders._create_invoices(final=self.deduct_down_payments)
                return super(SaleAdvancePaymentInv, self).create_invoices()
            if rec.partner_id.accounting_invoice_policy == 'never_combine_invoice':
                sale_orders._create_invoices(True)
                return super(SaleAdvancePaymentInv, self).create_invoices()

            else:
                print("Group By VAT Else >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
                sale_orders.with_context(by_vat=True)._create_invoices()
                # for rec in orderline:
                    # print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>',rec)

                print('---------------------saleorder-------',sale_orders._context)
                # return super(SaleAdvancePaymentInv, self).create_invoices()
            # else:
                # # Only we have to Work for 3rd option right YEs sir Okay c
                # # sale_orders._create_invoices()
                # # if not grouped:
                # print("hitanshiiiiiiiiiiiiiiiiiiiiiiiii")
                # sale_orders = sale_orders.with_context(by_vat=True)
                # for rec in sale_orders:
                #     new_invoice_vals_list = []
                #     invoice_vals_list = []
                #     invoice_grouping_keys = rec._get_invoice_grouping_keys()
                #     print('--------------------------------invoice_grouping_keys--',invoice_grouping_keys)
                #     invoice_vals_list = sorted(
                #         invoice_vals_list,
                #         key=lambda x: [
                #             x.get(grouping_key) for grouping_key in invoice_grouping_keys
                #         ]
                #     )
                #     for grouping_keys, invoices in groupby(invoice_vals_list, key=lambda x: [x.get(grouping_key) for grouping_key in invoice_grouping_keys]):
                #         origins = set()
                #         payment_refs = set()
                #         refs = set()
                #         ref_invoice_vals = None
                #         print('ref_invoice_vals=========45545================',ref_invoice_vals)
                #         for invoice_vals in invoices:
                #             print('ref_invoice_vals=======45454==================',invoice_vals)
                #             if not ref_invoice_vals:
                #                 print('ifffffffffffffffff4545ffffffffffffffffffff')
                #                 ref_invoice_vals = invoice_vals
                #                 # print('ref_invoice_vals========================',ref_invoice_vals)
                #             else:
                #                 print('elseeeeeeeeeeeeeee454eeeeeeeeeeeeeeeeee')
                #                 ref_invoice_vals['invoice_line_ids'] += invoice_vals['invoice_line_ids']
                #                 # print('-------------------------------ref_invoice_vals',ref_invoice_vals)
                #             origins.add(invoice_vals['invoice_origin'])
                #             payment_refs.add(invoice_vals['payment_reference'])
                #             refs.add(invoice_vals['ref'])
                #         ref_invoice_vals.update({
                #             'ref': ', '.join(refs)[:2000],
                #             'invoice_origin': ', '.join(origins),
                #             'payment_reference': len(payment_refs) == 1 and payment_refs.pop() or False,
                #         })
                #         # print('ref_invoice_vals--------------------------',ref_invoice_vals)
                #         new_invoice_vals_list.append(ref_invoice_vals)
                #         # print('=======new_invoice_vals_list==============', new_invoice_vals_list)
                #     invoice_vals_list = new_invoice_vals_list
                #     # print('--invoice_vals_list-------------------------------------------',invoice_vals_list)


                # # print('split------------------------------')
                # # # invoice_vals_list = []
                # # ref_invoice_vals = None
                # # sale_orders = sale_orders.with_context(by_vat=True)
                # # if sale_orders:
                # #     print('context--------------------------------saleorder',sale_orders._context)
                # #     print('sale_orders>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
                # #     sale_orders._create_invoices(True)
                # #     res = super(SaleAdvancePaymentInv, self).create_invoices()
                # #     # else:
                # #     #     sale_orders._create_invoices(True)
                # #     #     print("All Are not Sam,eeeeehhhhhhhhhhhhhhhhhhhhhhhhh",sale_orders)
                # #     #     res = super(SaleAdvancePaymentInv, self).create_invoices()
                # # # if sale_orders.with_context()._create_invoices():
                # # #     res = super(SaleAdvancePaymentInv, self).create_invoices()
                # # #     sale_orders._create_invoices(True)

                # #     print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>invoices>>')
                # # # if invoices:
                # # #     invoice_grouping_keys = rec._get_invoice_grouping_keys()
                # # #     print('invoice_grouping_keys----------------------',invoice_grouping_keys)
                # # #     s
                # # #     sale_orders._create_invoices(True)
                # # #     print("All Are not Sam,eeeee",sale_orders)
                # # #     res = super(SaleAdvancePaymentInv, self).create_invoices()
                # # #     # res = super(SaleAdvancePaymentInv, self).create_invoices()
                # # #     # sale_orders._create_invoices(final=self.deduct_down_payments)
                # # #     print('hitanshiiiiiiiiiiiiiiiiiiiiiiiiiiiiii')
                # # #     print('====invoicesss=============================',rec._context)
                # # # else:


                 

        # return res
        