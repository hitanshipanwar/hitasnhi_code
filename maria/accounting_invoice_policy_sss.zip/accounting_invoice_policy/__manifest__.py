# -*- coding: utf-8 -*-
{
    'name': "Accounting Invoice Policy",
    'summary': """Accounting Invoice policy""",
    'description': """Accounting Invoice policy""",
    'author': "Linserv Aktiebolag",
    'website': "https://www.linserv.se",
    'category': 'Uncategorized',
    'contributors': ['Sujeet Butani <sujeet.butani@linserv.se>'],
    'version': '0.1',
    'depends': ['base','account','sale'],
    'data': [
        'views/views.xml',
    ],
}
